<?php
session_start();
session_unset();  // Clear all session variables
session_destroy(); // Destroy the session

// Correct Redirect Path
header("Location: /library-management-system/index.php");
exit;
?>
