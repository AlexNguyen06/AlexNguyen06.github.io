<?php
session_start();
include_once 'C:/xampp1/htdocs/library-management-system/assets/webpages/db-connect.php';

// Ensure user is logged in
if (!isset($_SESSION['stdloggedin']) || $_SESSION['stdloggedin'] !== true) {
    header('Location: ../../webpages/student-login.php');
    exit;
}

// Ensure email is stored in session
if (!isset($_SESSION['std-email'])) {
    echo "Error: Student email is not set in session.";
    exit;
}

$student_email = $_SESSION['std-email'];

// Fetch student details
$student_query = "SELECT * FROM student WHERE email = '$student_email'";
$student_result = mysqli_query($con, $student_query);
$student_data = mysqli_fetch_assoc($student_result);
$student_id = $student_data['id'] ?? null;

if (!$student_id) {
    die("Error: Student ID not found.");
}

// Return Due Date for Next Book
$due_date_query = "SELECT duedate FROM issuebook WHERE userid = '$student_id' AND status = 'issued' ORDER BY duedate ASC LIMIT 1";
$due_date_result = mysqli_query($con, $due_date_query);
$due_date_data = mysqli_fetch_assoc($due_date_result);
$return_due_date = $due_date_data['duedate'] ?? "No due books";

// New Arrivals (Latest 3 Books)
$new_arrivals_query = "SELECT title FROM book ORDER BY id DESC LIMIT 3";
$new_arrivals_result = mysqli_query($con, $new_arrivals_query);
$new_arrivals = [];
while ($row = mysqli_fetch_assoc($new_arrivals_result)) {
    $new_arrivals[] = $row['title'];
}

// Notifications (Due Books, Approvals)
$notifications = [];
if ($return_due_date !== "No due books") {
    $notifications[] = "Your book is due on $return_due_date!";
}

// Pending Book Requests
$pending_requests_query = "SELECT COUNT(*) AS total FROM book_request WHERE std_id = '$student_id' AND status = 'pending'";
$pending_requests_result = mysqli_query($con, $pending_requests_query);
$pending_requests = mysqli_fetch_assoc($pending_requests_result)['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="../../css/index.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #e9edf2;
            margin: 0;
            padding: 0;
        }
        .dashboard {
            display: flex;
        }
        .sidebar {
            width: 220px;
            height: 100vh;
            background: #2c2f33;
            padding: 15px;
            color: white;
        }
        .sidebar a {
            text-decoration: none;
            display: block;
            color: white;
            padding: 12px;
            margin: 5px 0;
            transition: 0.3s;
        }
        .sidebar a:hover {
            background: #7289da;
            border-radius: 5px;
        }
        .content {
            flex: 1;
            padding: 20px;
        }
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logout-btn {
            background: #e74c3c;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .logout-btn:hover {
            background: #c0392b;
        }
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .card {
            background: white;
            padding: 25px;
            border-radius: 8px;
            text-align: center;
            color: white;
            font-weight: bold;
        }
        .card:nth-child(1) { background: #6a5acd; }
        .card:nth-child(2) { background: #3498db; }
        .card:nth-child(3) { background: #f39c12; }
        .card:nth-child(4) { background: #e74c3c; }
    </style>
</head>
<body>
    <div class="dashboard">
        <div class="sidebar">
            <h2>Library</h2>
            <a href="books.php">📚 Books</a>
            <a href="profile.php">👤 Profile</a>
            <a href="logout.php">🚪 Logout</a>
        </div>

        <div class="content">
            <div class="top-bar">
                <h2>📊 Student Dashboard</h2>
                <button class="logout-btn" onclick="window.location.href='logout.php'">Log Out</button>
            </div>

            <div class="dashboard-cards">
                <div class="card">
                    <h2><?php echo $return_due_date; ?></h2>
                    <p>Next Return Due Date</p>
                </div>
                <div class="card">
                    <h2><?php echo implode(", ", $new_arrivals); ?></h2>
                    <p>New Arrivals</p>
                </div>
                <div class="card">
                    <h2><?php echo implode("<br>", $notifications); ?></h2>
                    <p>Notifications</p>
                </div>
                <div class="card">
                    <h2><?php echo $pending_requests; ?></h2>
                    <p>Pending Requests</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
